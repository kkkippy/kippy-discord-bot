"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RandomPhrase = void 0;
const Warning = ["Cuidado!", "Quase!", "Por pouco!", "Ufa!"];
const Enemies = ["Nossos coelhinhos da floresta", "Nossas toupeiras de broto", "Nossos peixes coelhinhos"];
const Actions = ["roeram", "puxaram", "romperam"];
function RandomRange(array) {
    return Math.floor(Math.random() * array.length);
}
function RandomPhrase() {
    return `${Warning[RandomRange(Warning)]} ${Enemies[RandomRange(Enemies)]} ${Actions[RandomRange(Actions)]}`;
}
exports.RandomPhrase = RandomPhrase;
