"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SendTicketLog = exports.SendPunishmentLog = void 0;
const punishmentLogChannelId = "1230843907114532866";
const ticket = {
    "create": {
        logChannelId: "1178210754432868412",
        build: (member, ticket) => `${member} (${member.id}) **criou** um ticket em ${ticket}.`,
    },
    "close": {
        logChannelId: "1178331056580075651",
        build: (member, ticket) => `${member} (${member.id}) **fechou** seu ticket em ${ticket}.`,
    }
};
const SendPunishmentLog = async (guild, reason) => {
    const punishmentLogChannel = guild?.channels.cache.get(punishmentLogChannelId);
    if (punishmentLogChannel)
        punishmentLogChannel.send(reason);
};
exports.SendPunishmentLog = SendPunishmentLog;
const SendTicketLog = (interaction, action, customMessage) => {
    const guild = interaction.guild;
    const ticketChannel = interaction.channel;
    const options = ticket[action];
    const ticketLogChannel = guild?.channels.cache.get(options.logChannelId);
    ticketLogChannel.send(customMessage || options.build(interaction.member, ticketChannel));
};
exports.SendTicketLog = SendTicketLog;
