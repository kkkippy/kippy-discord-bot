"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getUrls = exports.hasUrl = exports.weekInMilliseconds = exports.weekInSeconds = exports.day = exports.hour = exports.minute = exports.second = void 0;
exports.second = 1000;
exports.minute = exports.second * 60;
exports.hour = exports.minute * 60;
exports.day = exports.hour * 24;
exports.weekInSeconds = (60 ** 2) * 24 * 7;
exports.weekInMilliseconds = exports.weekInSeconds * 1000;
const urlPattern = /(https?:\/\/)?[\w-]+\.[\w-]+[^ ]*/g;
const hasUrl = (text) => urlPattern.test(text);
exports.hasUrl = hasUrl;
const getUrls = (text) => {
    const matchedUrls = encodeURI(text).match(urlPattern);
    const urlSet = new Set();
    for (let urlIndex in matchedUrls) {
        let url = matchedUrls[urlIndex];
        if (!url.startsWith("http"))
            url = "https://" + url;
        console.log("URL obtida:", url);
        urlSet.add(new URL(url));
    }
    return urlSet;
};
exports.getUrls = getUrls;
