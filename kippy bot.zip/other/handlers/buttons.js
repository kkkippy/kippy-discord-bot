"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.buttons = void 0;
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
exports.buttons = [];
const initialFolder = path_1.default.join(__dirname, "..", "buttons");
readFolder(initialFolder);
function readFolder(dirPath) {
    let folder = fs_1.default.readdirSync(dirPath);
    for (const file of folder) {
        readFile(path_1.default.join(dirPath, file));
    }
}
function readFile(filePath) {
    const file = fs_1.default.lstatSync(filePath);
    if (file.isFile()) {
        const button = require(filePath);
        if (button.buttonContext && button.execute)
            exports.buttons.push(button);
    }
    if (file.isDirectory()) {
        readFolder(filePath);
    }
}
