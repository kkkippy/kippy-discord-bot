"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.slashCommands = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
exports.slashCommands = [];
const initialFolder = path_1.default.join(__dirname, "..", "slash");
readFolder(initialFolder);
function readFolder(dirPath) {
    let folder = fs_1.default.readdirSync(dirPath);
    for (const file of folder) {
        readFile(path_1.default.join(dirPath, file));
    }
}
function readFile(filePath) {
    const file = fs_1.default.lstatSync(filePath);
    if (file.isFile()) {
        const slash = require(filePath);
        if (slash.data && slash.execute)
            exports.slashCommands.push(slash);
    }
    if (file.isDirectory()) {
        readFolder(filePath);
    }
}
