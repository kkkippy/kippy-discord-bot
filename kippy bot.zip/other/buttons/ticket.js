"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.execute = exports.buttonContext = exports.ticketCache = void 0;
const discord_js_1 = require("discord.js");
const buildEmbed_1 = require("../utils/buildEmbed");
const logs_1 = require("../utils/logs");
const utils_1 = require("../utils/utils");
const mods_1 = require("../utils/mods");
async function getCorrespondingEmbed(channel) {
    if (channel.name === "sugestões")
        return await (0, buildEmbed_1.BuildCloseSuggestionTicketEmbed)();
    if (channel.name === "suporte")
        return await (0, buildEmbed_1.BuildCloseSupportTicketEmbed)();
    return new discord_js_1.EmbedBuilder()
        .setTitle("Algo deu errado...");
}
const singularName = {
    "sugestões": "sugestão"
};
exports.ticketCache = new Map();
async function createTicket(interaction) {
    const currentTicket = exports.ticketCache.get(interaction.user.id);
    if (currentTicket)
        return interaction.reply({ content: `Você já possui um ticket em ${currentTicket}`, ephemeral: true });
    const channel = interaction.channel;
    const ticketCategory = singularName[channel.name] || channel.name;
    const thread = await channel.threads.create({
        type: discord_js_1.ChannelType.PrivateThread,
        invitable: false,
        name: `${interaction.user.id} | ${ticketCategory}`,
    });
    exports.ticketCache.set(interaction.user.id, thread);
    (0, logs_1.SendTicketLog)(interaction, "create");
    await thread.members.add(interaction.user);
    const closeTicketEmbed = await getCorrespondingEmbed(channel);
    const closeButton = new discord_js_1.ButtonBuilder()
        .setStyle(discord_js_1.ButtonStyle.Danger)
        .setCustomId("ticket:close")
        .setLabel("Fechar ticket");
    const row = new discord_js_1.ActionRowBuilder()
        .setComponents(closeButton);
    thread.send({ content: "<@&1178324960603807795>", embeds: [closeTicketEmbed], components: [row] });
    await interaction.reply({ content: `Ticket criado em ${thread}.`, ephemeral: true });
}
async function closeTicket(interaction) {
    if (!exports.ticketCache.has(interaction.user.id) && !mods_1.mods[interaction.user.id])
        return await interaction.reply({ content: `Você não possui um ticket para fechar.`, ephemeral: true });
    exports.ticketCache.delete(interaction.user.id);
    const ticket = interaction.channel;
    interaction.reply(`${interaction.user}, este ticket será fechado em 10 segundos.`).catch(console.log);
    setTimeout(() => {
        (0, logs_1.SendTicketLog)(interaction, "close");
        ticket.members.cache.forEach(member => {
            if (exports.ticketCache.has(member.id))
                exports.ticketCache.delete(member.id);
            member.remove().catch(console.log);
        });
    }, utils_1.second * 10);
}
exports.buttonContext = "ticket";
const execute = async (interaction, action) => {
    if (action === "create")
        await createTicket(interaction);
    if (action === "close")
        await closeTicket(interaction);
};
exports.execute = execute;
