"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.execute = exports.requiredPermission = exports.data = void 0;
const discord_js_1 = require("discord.js");
const buildEmbed_1 = require("../../utils/buildEmbed");
const randomPhrase_1 = require("../../utils/randomPhrase");
const utils_1 = require("../../utils/utils");
const logs_1 = require("../../utils/logs");
const mods_1 = require("../../utils/mods");
const client_1 = require("../../client");
exports.data = new discord_js_1.SlashCommandBuilder()
    .setName("mute")
    .setDescription("Silencia um usuário.")
    .addUserOption(option => option
    .setName("usuario")
    .setDescription("Selecione o usuário no qual deseja silenciar.")
    .setRequired(true))
    .addStringOption(option => option
    .setName("duracao")
    .setDescription("Seleciona a duração do silenciamento.")
    .setChoices({ name: "1 minuto", value: `1 minuto:${utils_1.minute}` }, { name: "10 minutos", value: `10 minutos:${utils_1.minute * 10}` }, { name: "30 minutos", value: `30 minutos:${utils_1.minute * 30}` }, { name: "1 hora", value: `1 hora:${utils_1.hour}` }, { name: "6 horas", value: `6 horas:${utils_1.hour * 6}` }, { name: "12 horas", value: `12 horas:${utils_1.hour * 12}` }, { name: "1 dia", value: `1 dia:${utils_1.day}` }, { name: "7 dias", value: `7 dias:${utils_1.day * 7}` })
    .setRequired(true))
    .addStringOption(option => option
    .setName("motivo")
    .setDescription("Descreva o motivo do silenciamento."));
exports.requiredPermission = discord_js_1.PermissionFlagsBits.MuteMembers;
const execute = async (interaction) => {
    const duration = interaction.options.getString("duracao").split(":");
    const reason = interaction.options.getString("motivo") || "Não especificado.";
    const user = interaction.options.getUser("usuario");
    if (user === interaction.user)
        return interaction.reply(`${(0, randomPhrase_1.RandomPhrase)()} o cabo de ${interaction.client.user} antes que você pudesse se autossilenciar!`);
    if (mods_1.mods[user.id])
        return interaction.reply(`Ei, o que você pensa que tá fazendo?`);
    const durationAsNumber = Number(duration[1]);
    const durationAsText = duration[0];
    const guild = client_1.client.guilds.cache.first();
    const member = guild.members.cache.get(user?.id);
    const muteEmbed = await (0, buildEmbed_1.BuildPunishmentEmbed)({
        title: `Você foi silenciado em ${guild.name}.`,
        punishedBy: interaction.user,
        reason,
    });
    await member?.send({ embeds: [muteEmbed] }).catch(console.log);
    await member?.timeout(durationAsNumber, reason)
        .then(() => {
        interaction.reply(`O membro ${user} (${user?.id}) foi silenciado por ${durationAsText} em ${guild.name}.`);
        (0, logs_1.SendPunishmentLog)(guild, `O membro ${user} foi **silenciado** por **${interaction.user.username}** durante **${durationAsText}** em ${guild.name} pelo motivo: **${reason}**`);
    })
        .catch(e => {
        interaction.reply(`Não foi possível silenciar o membro ${user} (${user?.id}).\n${e}.`);
    });
};
exports.execute = execute;
