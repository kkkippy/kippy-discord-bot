"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.execute = exports.requiredPermission = exports.data = void 0;
const discord_js_1 = require("discord.js");
const buildEmbed_1 = require("../../utils/buildEmbed");
const randomPhrase_1 = require("../../utils/randomPhrase");
const logs_1 = require("../../utils/logs");
const basilEmotions_json_1 = __importDefault(require("../../utils/basilEmotions.json"));
const utils_1 = require("../../utils/utils");
const banGifs_1 = require("../../utils/banGifs");
const mods_1 = require("../../utils/mods");
const client_1 = require("../../client");
exports.data = new discord_js_1.SlashCommandBuilder()
    .setName("ban")
    .setDescription("Bane um usuário.")
    .addUserOption(option => option
    .setName("usuario")
    .setDescription("Selecione o usuário no qual deseja banir.")
    .setRequired(true))
    .addStringOption(option => option
    .setName("motivo")
    .setDescription("Descreva o motivo do banimento."));
exports.requiredPermission = discord_js_1.PermissionFlagsBits.BanMembers;
const execute = async (interaction) => {
    const reason = interaction.options.getString("motivo") || "Não especificado.";
    const user = interaction.options.getUser("usuario");
    if (user === interaction.user)
        return interaction.reply(`${(0, randomPhrase_1.RandomPhrase)()} o cabo de ${interaction.client.user} antes que você pudesse banir você mesmo!`);
    if (mods_1.mods[user.id])
        return interaction.reply(`Ei, o que você pensa que tá fazendo?`);
    const guild = client_1.client.guilds.cache.first();
    const member = guild.members.cache.get(user?.id);
    const banEmbed = await (0, buildEmbed_1.BuildPunishmentEmbed)({
        title: `Você foi banido de ${guild.name}.`,
        punishedBy: interaction.user,
        thumbnail: basilEmotions_json_1.default.muito_bravo,
        image: (0, banGifs_1.RandomGIF)(),
        color: 0xef2104,
        reason,
    });
    if (member)
        await member?.send({ embeds: [banEmbed] }).catch(console.log);
    /*
    Imagino que deva causar pânico no código caso o usuário esteja no servidor
    mas tenha bloqueado o bot, então como forma de prevenir esse pânico,
    fiz o tratamento do possível erro usando o catch
    */
    await guild.members?.ban(user, { reason, deleteMessageSeconds: utils_1.weekInSeconds })
        .then(() => {
        interaction.reply(`O usuário ${user} (${user?.id}) foi banido de ${guild.name}.`);
        (0, logs_1.SendPunishmentLog)(guild, `O usuário ${user} foi **banido** de ${guild.name} por **${interaction.user.username}** pelo motivo: **${reason}**`);
    })
        .catch(e => {
        interaction.reply(`Não foi possível banir o usuário ${user} (${user?.id}).\n${e}.`);
    });
};
exports.execute = execute;
