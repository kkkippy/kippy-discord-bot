"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.execute = exports.requiredPermission = exports.data = void 0;
const discord_js_1 = require("discord.js");
const buildEmbed_1 = require("../../utils/buildEmbed");
const randomPhrase_1 = require("../../utils/randomPhrase");
const logs_1 = require("../../utils/logs");
const basilEmotions_json_1 = __importDefault(require("../../utils/basilEmotions.json"));
const mods_1 = require("../../utils/mods");
const client_1 = require("../../client");
exports.data = new discord_js_1.SlashCommandBuilder()
    .setName("kick")
    .setDescription("Expulsa um usuário.")
    .addUserOption(option => option
    .setName("usuario")
    .setDescription("Selecione o usuário no qual deseja expulsar.")
    .setRequired(true))
    .addStringOption(option => option
    .setName("motivo")
    .setDescription("Descreva o motivo do expulsamento."));
exports.requiredPermission = discord_js_1.PermissionFlagsBits.KickMembers;
const execute = async (interaction) => {
    const reason = interaction.options.getString("motivo") || "Não especificado.";
    const user = interaction.options.getUser("usuario");
    if (user === interaction.user)
        return interaction.reply(`${(0, randomPhrase_1.RandomPhrase)()} o cabo de ${interaction.client.user} antes que você pudesse expulsar a si mesmo!`);
    if (mods_1.mods[user.id])
        return interaction.reply(`Ei, o que você pensa que tá fazendo?`);
    const guild = client_1.client.guilds.cache.first();
    const member = guild.members.cache.get(user?.id);
    const kickEmbed = await (0, buildEmbed_1.BuildPunishmentEmbed)({
        title: `Você foi expulso de ${guild.name}.`,
        punishedBy: interaction.user,
        thumbnail: basilEmotions_json_1.default.mais_nervoso,
        color: 0xcc8658,
        reason,
    });
    if (member)
        await member?.send({ embeds: [kickEmbed] }).catch(console.log);
    await guild.members?.kick(user, reason)
        .then(() => {
        interaction.reply(`O usuário ${user} (${user?.id}) foi expulso de ${guild.name}.`);
        (0, logs_1.SendPunishmentLog)(guild, `O usuário ${user} foi **expulso** de ${guild.name} por **${interaction.user.username}** pelo motivo: **${reason}**`);
    })
        .catch(e => {
        interaction.reply(`Não foi possível expulsar o usuário ${user} (${user?.id}).\n${e}.`);
    });
};
exports.execute = execute;
