"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.execute = exports.data = void 0;
const discord_js_1 = require("discord.js");
exports.data = new discord_js_1.SlashCommandBuilder()
    .setName("server")
    .setDescription("Mostra as informações do servidor.")
    .setDMPermission(false);
const execute = async (interaction) => {
    await interaction.reply(`O servidor possui **${interaction.guild?.memberCount}** membros.`);
};
exports.execute = execute;
