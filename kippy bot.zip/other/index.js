"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const deploy_commands_1 = require("./deploy-commands");
const events_1 = require("./handlers/events");
const config_json_1 = require("./config.json");
const client_1 = require("./client");
events_1.events.forEach(event => client_1.client.on(event.eventName, event.execute));
(0, deploy_commands_1.deployCommands)();
client_1.client.login(config_json_1.token);
