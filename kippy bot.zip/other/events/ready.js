"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.execute = exports.eventName = void 0;
const discord_js_1 = require("discord.js");
exports.eventName = discord_js_1.Events.ClientReady;
const execute = async (client) => {
    console.log(client.user?.username + " está ligado!");
};
exports.execute = execute;
