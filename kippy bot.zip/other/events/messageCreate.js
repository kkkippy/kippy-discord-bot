"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.execute = exports.eventName = void 0;
const blacklist_1 = require("../utils/blacklist");
const discord_js_1 = require("discord.js");
exports.eventName = discord_js_1.Events.MessageCreate;
const execute = async (message) => {
    if ((0, blacklist_1.isBlacklisted)(message))
        return await (0, blacklist_1.moderateMessage)(message, "Envio de mensagem blacklisted.");
};
exports.execute = execute;
