"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.execute = exports.data = void 0;
const discord_js_1 = require("discord.js");
exports.data = new discord_js_1.SlashCommandBuilder()
    .setName("sapo")
    .setDescription("Algo terrível acontecerá ao executar este comando...")
    .setDMPermission(false);
const execute = async (interaction) => {
    const reply = await interaction.reply({ content: "https://media.discordapp.net/attachments/1172662617354010695/1233847582288253071/sapo_da_chuva.png", fetchReply: true });
    await reply.react("🐸");
};
exports.execute = execute;
