"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.execute = exports.data = void 0;
const discord_js_1 = require("discord.js");
exports.data = new discord_js_1.SlashCommandBuilder()
    .setName("js")
    .setDescription("...")
    .setDMPermission(false);
const execute = async (interaction) => {
    const reply = await interaction.reply({ content: "https://tenor.com/view/javascript-sad-programmer-sad-seal-js-frontend-gif-17530726856445672143", fetchReply: true });
    await reply.react("<:PensiveOrange:1217870358875603067>");
};
exports.execute = execute;
