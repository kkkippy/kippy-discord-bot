"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.execute = exports.data = void 0;
const discord_js_1 = require("discord.js");
exports.data = new discord_js_1.SlashCommandBuilder()
    .setName("userinfo")
    .setDescription("...")
    .setDMPermission(false)
    .addUserOption(option => option
    .setName("usuario")
    .setDescription("Selecione o usuário que deseja obter as informações")
    .setRequired(true));
const execute = async (interaction) => {
    const user = interaction.options.getUser("usuario");
    const guild = interaction.guild;
    if (!user)
        return;
    const createdTimestampInSeconds = Math.floor(user.createdTimestamp / 1000);
    const userinfoEmbed = new discord_js_1.EmbedBuilder()
        .setURL(`https://discord.com/users/${user.id}`)
        .setTitle((guild?.ownerId === user.id ? "👑 " : "👤 ") + user.displayName)
        .setThumbnail(user.avatarURL())
        .setColor(0xcccccc)
        .setFields({
        name: "ID do usuário:",
        value: user.id
    }, {
        name: "Username do Discord:",
        value: `${user.username}`
    }, {
        name: "Data de criação da conta:",
        value: `<t:${createdTimestampInSeconds}:F> (<t:${createdTimestampInSeconds}:R>)`
    });
    const member = await guild?.members.fetch({ user: user.id }).catch(console.log);
    if (member && member.joinedTimestamp) {
        const joinedTimestampInSeconds = Math.floor(member.joinedTimestamp / 1000);
        userinfoEmbed.addFields({
            name: "Entrou no servidor em:",
            value: `<t:${joinedTimestampInSeconds}:F> (<t:${joinedTimestampInSeconds}:R>)`
        });
    }
    interaction.reply({ content: `Exibindo as informações de **${user.username}** (${user.id}).`, embeds: [userinfoEmbed] });
};
exports.execute = execute;
