"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.execute = exports.requiredPermission = exports.data = void 0;
const discord_js_1 = require("discord.js");
const logs_1 = require("../../utils/logs");
exports.data = new discord_js_1.SlashCommandBuilder()
    .setName("force-ticket-close")
    .setDescription("...")
    .setDMPermission(false);
exports.requiredPermission = discord_js_1.PermissionFlagsBits.BanMembers;
const execute = async (interaction) => {
    const ticket = interaction.channel;
    if (ticket.type != discord_js_1.ChannelType.PrivateThread)
        return interaction.reply(`Este comando só pode ser utilizado em threads.`);
    (await ticket.members.fetch()).forEach(member => member.remove());
    await interaction.reply({ content: `Todos os membros foram removidos do ticket.`, ephemeral: true });
    (0, logs_1.SendTicketLog)(interaction, "close", `${interaction.user} (${interaction.user.id}) **forçou o fechamento** do ticket ${ticket}.`);
};
exports.execute = execute;
