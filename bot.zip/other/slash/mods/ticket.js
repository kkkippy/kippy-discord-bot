"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.execute = exports.requiredPermission = exports.data = void 0;
const discord_js_1 = require("discord.js");
const buildEmbed_1 = require("../../utils/buildEmbed");
async function getCorrespondingEmbed(interaction, channel) {
    if (channel.name === "sugestões")
        return await (0, buildEmbed_1.BuildCreateSuggestionTicketEmbed)(interaction);
    if (channel.name === "suporte")
        return await (0, buildEmbed_1.BuildCreateSupportTicketEmbed)(interaction);
    return new discord_js_1.EmbedBuilder()
        .setTitle("Algo deu errado...");
}
exports.data = new discord_js_1.SlashCommandBuilder()
    .setName("create-tickets")
    .setDescription("...")
    .setDMPermission(false);
exports.requiredPermission = discord_js_1.PermissionFlagsBits.MuteMembers;
const execute = async (interaction) => {
    const createButton = new discord_js_1.ButtonBuilder()
        .setLabel("Criar ticket")
        .setCustomId("ticket:create")
        .setStyle(discord_js_1.ButtonStyle.Success);
    const row = new discord_js_1.ActionRowBuilder()
        .setComponents(createButton);
    const ticketCategory = interaction.guild?.channels.cache.get("1166871569541373952");
    ticketCategory.children.cache.forEach(async (channel) => {
        if (channel.type === discord_js_1.ChannelType.GuildText) {
            const correspondingChannelEmbed = await getCorrespondingEmbed(interaction, channel);
            channel.send({ embeds: [correspondingChannelEmbed], components: [row] });
        }
    });
    interaction.reply({ content: `Mensagens setadas na categoria de tickets.`, ephemeral: true });
};
exports.execute = execute;
