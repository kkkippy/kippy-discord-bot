"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.events = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
exports.events = [];
const initialFolder = path_1.default.join(__dirname, "..", "events");
readFolder(initialFolder);
function readFolder(dirPath) {
    let folder = fs_1.default.readdirSync(dirPath);
    for (const file of folder) {
        readFile(path_1.default.join(dirPath, file));
    }
}
function readFile(filePath) {
    const file = fs_1.default.lstatSync(filePath);
    if (file.isFile()) {
        const event = require(filePath);
        if (event.eventName && event.execute)
            exports.events.push(event);
    }
    if (file.isDirectory()) {
        readFolder(filePath);
    }
}
