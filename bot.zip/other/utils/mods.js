"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mods = void 0;
const discord_js_1 = require("discord.js");
const AllPermissions = [
    discord_js_1.PermissionsBitField.Flags.MuteMembers,
    discord_js_1.PermissionsBitField.Flags.KickMembers,
    discord_js_1.PermissionsBitField.Flags.BanMembers,
];
exports.mods = {
    "1100135686948012213": AllPermissions, // Kippy
    "884296522345369622": AllPermissions, // Ianwu8
    "1203512811540709447": AllPermissions, // Woo
};
