"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.moderateMessage = exports.isBlacklisted = void 0;
const buildEmbed_1 = require("./buildEmbed");
const utils_1 = require("./utils");
const logs_1 = require("./logs");
const client_1 = require("../client");
const mods_1 = require("./mods");
const blacklistedHosts = [
    "pornhub.com",
    "xvideos.com",
    "rule34.xxx"
];
const whitelistedInvites = [
    "kippy",
    "rodevs",
    "hd"
];
async function MuteMember(member, reason, message) {
    if (mods_1.mods[member.id])
        return;
    const guild = member.guild;
    const muteEmbed = await (0, buildEmbed_1.BuildPunishmentEmbed)({
        title: `Você foi silenciado em ${guild.name}.`,
        punishedBy: client_1.client.user,
        reason,
    });
    await member.timeout(utils_1.minute * 10, reason)
        .then(() => {
        if (message)
            message.channel.send(`O usuário ${member} (${member.id}) foi silenciado **automaticamente** por **10 minutos** por enviar uma mensagem blacklisted.`);
        member.send({ embeds: [muteEmbed] }).catch(console.log);
        (0, logs_1.SendPunishmentLog)(guild, `O usuário ${member} (${member.id}) foi silenciado **automaticamente** por **10 minutos** pelo motivo: **${reason}**`);
    })
        .catch(console.log);
}
const isWhitelistedInvite = (inviteName) => whitelistedInvites.includes(inviteName);
const isDiscordInvite = (url, paths) => (url.hostname === "discord.gg" || `${url.hostname + url.pathname}`.startsWith("discord.com/invite")) && paths.length != 0;
function isBlacklistedHost(hostname) {
    for (const blacklistedHost of blacklistedHosts) {
        if (blacklistedHost.startsWith(hostname))
            return true;
    }
}
function isBlacklisted(message) {
    if (!(0, utils_1.hasUrl)(message.content))
        return false;
    const urls = (0, utils_1.getUrls)(message.content);
    for (const url of urls) {
        const paths = url.pathname.split("/").filter(Boolean).map(path => path.toLocaleLowerCase());
        const invite = paths[paths.length - 1];
        if (isBlacklistedHost(url.hostname))
            return true;
        if (isDiscordInvite(url, paths) && !isWhitelistedInvite(invite))
            return true;
    }
}
exports.isBlacklisted = isBlacklisted;
async function moderateMessage(message, reason) {
    const member = message.member;
    if (!member || mods_1.mods[member.id])
        return;
    if (message.deletable)
        message.delete();
    await MuteMember(member, reason, message);
}
exports.moderateMessage = moderateMessage;
