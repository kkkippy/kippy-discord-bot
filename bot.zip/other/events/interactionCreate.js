"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.execute = exports.eventName = void 0;
const discord_js_1 = require("discord.js");
const slash_1 = require("../handlers/slash");
const mods_1 = require("../utils/mods");
const client_1 = require("../client");
exports.eventName = discord_js_1.Events.InteractionCreate;
const execute = async (interaction) => {
    if (!interaction.isChatInputCommand())
        return;
    const slashCommand = slash_1.slashCommands.find(cmd => cmd.data.name === interaction.commandName);
    if (!slashCommand)
        return interaction.reply(`Nenhuma correspondência foi encontrada para o comando ${interaction.commandName}.`);
    let guild = client_1.client.guilds.cache.first();
    let member = guild?.members.cache.get(interaction.user.id);
    if ((!member // Se não possuir o objeto membro,
        || !mods_1.mods[member.id] // ou não estiver na lista de moderadores/administradores,
        || !mods_1.mods[member.id].includes(slashCommand.requiredPermission) // ou não possuir a permissão necessária para executar o comando,
    )
        && slashCommand.requiredPermission // e o comando exigir permissão para ser executado
    )
        return interaction.reply("Você não tem permissão para usar este comando.");
    return slashCommand.execute(interaction)
        .catch(async (e) => {
        if (interaction.deferred || interaction.replied) {
            await interaction.followUp({ content: `Ocorreu um erro ao executar este comando: ${e}` });
        }
    });
};
exports.execute = execute;
