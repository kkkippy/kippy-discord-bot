"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.execute = exports.eventName = void 0;
const blacklist_1 = require("../utils/blacklist");
const discord_js_1 = require("discord.js");
exports.eventName = discord_js_1.Events.MessageUpdate;
const execute = async (oldMessage, newMessage) => {
    if (oldMessage.author.bot)
        return;
    if ((0, blacklist_1.isBlacklisted)(newMessage))
        return await (0, blacklist_1.moderateMessage)(newMessage, "Envio de mensagem blacklisted.");
};
exports.execute = execute;
