"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.execute = exports.eventName = void 0;
const discord_js_1 = require("discord.js");
const buttons_1 = require("../handlers/buttons");
exports.eventName = discord_js_1.Events.InteractionCreate;
const execute = async (interaction) => {
    if (!interaction.isButton())
        return;
    const buttonProperties = interaction.customId.split(":");
    const buttonContext = buttonProperties.shift();
    const button = buttons_1.buttons.find(bt => bt.buttonContext === buttonContext);
    if (!button)
        return interaction.reply(`Nenhuma correspondência foi encontrada para o botão ${interaction.customId}`);
    button?.execute(interaction, ...buttonProperties);
};
exports.execute = execute;
