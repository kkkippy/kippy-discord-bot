"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deployCommands = void 0;
const slash_1 = require("./handlers/slash");
const config_json_1 = require("./config.json");
const discord_js_1 = require("discord.js");
const deployCommands = async () => {
    const rest = new discord_js_1.REST().setToken(config_json_1.token);
    const body = {
        body: slash_1.slashCommands.map(slashCommand => slashCommand.data.toJSON())
    };
    await rest.put(discord_js_1.Routes.applicationCommands(config_json_1.clientId), body)
        .then(() => console.log(`${body.body.length} comando(s) recarregado(s).`));
};
exports.deployCommands = deployCommands;
